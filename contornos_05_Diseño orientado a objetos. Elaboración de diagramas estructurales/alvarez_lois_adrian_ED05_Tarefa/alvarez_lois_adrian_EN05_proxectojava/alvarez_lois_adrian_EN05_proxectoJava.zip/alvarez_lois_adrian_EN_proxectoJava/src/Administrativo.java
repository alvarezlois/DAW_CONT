public class Administrativo {

	private string nombre;

	public Administrativo() {
		// TODO - implement Administrativo.Administrativo
		throw new UnsupportedOperationException();
	}

	public string getNombre() {
		return this.nombre;
	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(string nombre) {
		this.nombre = nombre;
	}

}