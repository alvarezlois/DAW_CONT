public class Proveedor {

	private string nombre;
	private int cif;
	private string domicilioFiscal;

	public void Proveedores() {
		// TODO - implement Proveedor.Proveedores
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nombre
	 * @param cif
	 * @param domicilioFiscal
	 */
	public void Proveedores(string nombre, int cif, string domicilioFiscal) {
		// TODO - implement Proveedor.Proveedores
		throw new UnsupportedOperationException();
	}

	public string getNombre() {
		return this.nombre;
	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(string nombre) {
		this.nombre = nombre;
	}

	public int getCif() {
		return this.cif;
	}

	/**
	 * 
	 * @param cif
	 */
	public void setCif(int cif) {
		this.cif = cif;
	}

	public string getDomicilioFiscal() {
		return this.domicilioFiscal;
	}

	/**
	 * 
	 * @param domicilioFiscal
	 */
	public void setDomicilioFiscal(string domicilioFiscal) {
		this.domicilioFiscal = domicilioFiscal;
	}

}