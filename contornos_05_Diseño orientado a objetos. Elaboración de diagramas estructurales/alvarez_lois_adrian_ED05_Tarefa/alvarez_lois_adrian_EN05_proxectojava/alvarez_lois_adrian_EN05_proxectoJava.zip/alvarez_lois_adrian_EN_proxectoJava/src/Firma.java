public class Firma {

	private string nombre;
	private int cif;
	private string domicilioFiscal;

}