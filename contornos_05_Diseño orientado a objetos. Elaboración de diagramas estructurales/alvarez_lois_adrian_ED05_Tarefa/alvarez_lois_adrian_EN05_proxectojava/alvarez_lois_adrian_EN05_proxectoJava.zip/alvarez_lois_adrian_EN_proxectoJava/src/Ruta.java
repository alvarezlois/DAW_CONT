public class Ruta {

	private string areaInfluencia;
	private string diasReparto;
	private date fecha;

	public Ruta() {
		// TODO - implement Ruta.Ruta
		throw new UnsupportedOperationException();
	}

	public string getAreaInfluencia() {
		return this.areaInfluencia;
	}

	/**
	 * 
	 * @param areaInfluencia
	 */
	public void setAreaInfluencia(string areaInfluencia) {
		this.areaInfluencia = areaInfluencia;
	}

	public string getDiasReparto() {
		return this.diasReparto;
	}

	/**
	 * 
	 * @param diasReparto
	 */
	public void setDiasReparto(string diasReparto) {
		this.diasReparto = diasReparto;
	}

	public date getFecha() {
		return this.fecha;
	}

	/**
	 * 
	 * @param fecha
	 */
	public void setFecha(date fecha) {
		this.fecha = fecha;
	}

	/**
	 * 
	 * @param disSocio
	 */
	public string destino(string disSocio) {
		// TODO - implement Ruta.destino
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param fecha
	 */
	public date diasReparto(date fecha) {
		// TODO - implement Ruta.diasReparto
		throw new UnsupportedOperationException();
	}

}