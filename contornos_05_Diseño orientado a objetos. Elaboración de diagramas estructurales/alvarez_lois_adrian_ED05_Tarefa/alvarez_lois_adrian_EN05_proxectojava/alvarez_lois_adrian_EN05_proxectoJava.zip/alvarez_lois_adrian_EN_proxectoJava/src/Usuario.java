public class Usuario {

	private string nombre;
	private string email;

	public Usuario() {
		// TODO - implement Usuario.Usuario
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nombre
	 * @param email
	 */
	public Usuario(string nombre, string email) {
		// TODO - implement Usuario.Usuario
		throw new UnsupportedOperationException();
	}

	public string getNombre() {
		return this.nombre;
	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(string nombre) {
		this.nombre = nombre;
	}

	public string getEmail() {
		return this.email;
	}

	/**
	 * 
	 * @param email
	 */
	public void setEmail(string email) {
		this.email = email;
	}

	public void getAttribute() {
		// TODO - implement Usuario.getAttribute
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param attribute
	 */
	public void setAttribute(int attribute) {
		// TODO - implement Usuario.setAttribute
		throw new UnsupportedOperationException();
	}

}