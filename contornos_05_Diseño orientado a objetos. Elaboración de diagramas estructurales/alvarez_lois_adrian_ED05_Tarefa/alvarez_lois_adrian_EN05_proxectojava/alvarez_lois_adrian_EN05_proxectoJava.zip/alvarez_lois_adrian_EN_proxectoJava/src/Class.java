public class Class {
}