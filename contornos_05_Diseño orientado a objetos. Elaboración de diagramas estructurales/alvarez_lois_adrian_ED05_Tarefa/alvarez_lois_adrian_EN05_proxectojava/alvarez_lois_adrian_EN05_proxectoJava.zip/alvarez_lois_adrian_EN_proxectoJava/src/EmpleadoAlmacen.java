public class EmpleadoAlmacen {

	private string nombre;

	public EmpleadoAlmacen() {
		// TODO - implement EmpleadoAlmacen.EmpleadoAlmacen
		throw new UnsupportedOperationException();
	}

	public string getNombre() {
		return this.nombre;
	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(string nombre) {
		this.nombre = nombre;
	}

}