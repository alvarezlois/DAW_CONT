public class Campaña {

	private string temporada;

}