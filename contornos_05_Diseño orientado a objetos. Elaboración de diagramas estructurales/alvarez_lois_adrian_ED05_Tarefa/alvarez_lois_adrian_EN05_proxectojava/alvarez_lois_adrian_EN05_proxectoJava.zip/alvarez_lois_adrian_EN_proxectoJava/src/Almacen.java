public class Almacen {

	private int paqueteNum;
	private string destino;

	public Almacen() {
		// TODO - implement Almacen.Almacen
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param disSocio
	 */
	public string asignarDestino(string disSocio) {
		// TODO - implement Almacen.asignarDestino
		throw new UnsupportedOperationException();
	}

}