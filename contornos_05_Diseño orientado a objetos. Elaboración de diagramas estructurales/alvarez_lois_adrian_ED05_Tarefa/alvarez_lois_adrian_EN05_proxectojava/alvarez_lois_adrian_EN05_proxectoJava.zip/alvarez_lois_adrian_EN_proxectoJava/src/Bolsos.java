public class Bolsos {

	private string tipo;
	private Articulos articulo;

	public string getTipo() {
		return this.tipo;
	}

	public Articulos getArticulo() {
		return this.articulo;
	}

	/**
	 * 
	 * @param tipo
	 */
	public void setTipo(string tipo) {
		this.tipo = tipo;
	}

	/**
	 * 
	 * @param articulo
	 */
	public void setArticulo(Articulos articulo) {
		this.articulo = articulo;
	}

}