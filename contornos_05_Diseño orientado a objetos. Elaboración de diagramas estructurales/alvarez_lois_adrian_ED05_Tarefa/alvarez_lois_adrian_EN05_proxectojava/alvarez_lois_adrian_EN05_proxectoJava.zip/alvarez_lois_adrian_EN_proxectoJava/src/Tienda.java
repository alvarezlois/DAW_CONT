public class Tienda {

	public void mostrarComplementos() {
		// TODO - implement Tienda.mostrarComplementos
		throw new UnsupportedOperationException();
	}

	public void mostrarZapatos() {
		// TODO - implement Tienda.mostrarZapatos
		throw new UnsupportedOperationException();
	}

	public void mostrarBolsos() {
		// TODO - implement Tienda.mostrarBolsos
		throw new UnsupportedOperationException();
	}

}