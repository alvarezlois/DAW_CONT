public class Complementos {

	private Articulos articulo;
	private int Talla;

	public Articulos getArticulo() {
		return this.articulo;
	}

	/**
	 * 
	 * @param articulo
	 */
	public void setArticulo(Articulos articulo) {
		this.articulo = articulo;
	}

	public int getTalla() {
		// TODO - implement Complementos.getTalla
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Talla
	 */
	public void setTalla(int Talla) {
		// TODO - implement Complementos.setTalla
		throw new UnsupportedOperationException();
	}

}