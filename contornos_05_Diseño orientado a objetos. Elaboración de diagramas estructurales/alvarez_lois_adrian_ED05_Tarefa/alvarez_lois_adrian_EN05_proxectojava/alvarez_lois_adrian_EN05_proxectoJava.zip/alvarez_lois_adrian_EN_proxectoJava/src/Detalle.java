
import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;

public class Detalle {

	private Pedido pedido;
	private Articulos articulo;
	private float cantidad;
	private date fecha;

}