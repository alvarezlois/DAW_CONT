public class Zapatos {

	private Articulo articulo;
	private string tipo;
	private int numero;

	public Articulo getArticulo() {
		return this.articulo;
	}

	/**
	 * 
	 * @param articulo
	 */
	public void setArticulo(Articulo articulo) {
		this.articulo = articulo;
	}

	public string getTipo() {
		return this.tipo;
	}

	/**
	 * 
	 * @param tipo
	 */
	public void setTipo(string tipo) {
		this.tipo = tipo;
	}

	public int getNumero() {
		return this.numero;
	}

	/**
	 * 
	 * @param numero
	 */
	public void setNumero(int numero) {
		this.numero = numero;
	}

	public Zapatos() {
		// TODO - implement Zapatos.Zapatos
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param articulo
	 * @param tipo
	 * @param numero
	 */
	public Zapatos(Articulos articulo, string tipo, int numero) {
		// TODO - implement Zapatos.Zapatos
		throw new UnsupportedOperationException();
	}

}