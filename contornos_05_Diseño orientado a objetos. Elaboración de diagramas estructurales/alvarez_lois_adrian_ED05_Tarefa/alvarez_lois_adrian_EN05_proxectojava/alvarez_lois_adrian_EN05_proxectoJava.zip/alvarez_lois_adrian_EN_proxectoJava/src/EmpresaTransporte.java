public class EmpresaTransporte {

	private string nombre;
	private int cif;
	private string DomicilioFiscal;

	public EmpresaTransporte() {
		// TODO - implement EmpresaTransporte.EmpresaTransporte
		throw new UnsupportedOperationException();
	}

	public string getNombre() {
		return this.nombre;
	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(string nombre) {
		this.nombre = nombre;
	}

	public int getCif() {
		return this.cif;
	}

	/**
	 * 
	 * @param cif
	 */
	public void setCif(int cif) {
		this.cif = cif;
	}

	public string getDomicilioFiscal() {
		// TODO - implement EmpresaTransporte.getDomicilioFiscal
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param DomicilioFiscal
	 */
	public void setDomicilioFiscal(string DomicilioFiscal) {
		// TODO - implement EmpresaTransporte.setDomicilioFiscal
		throw new UnsupportedOperationException();
	}

}